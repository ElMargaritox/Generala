#include <iostream>
#include<stdlib.h>
#include<time.h>
using namespace std;

void CargarDatos(int Numeros[100]);
void MostrarDatos(int Numeros[100]);
int MostrarCantidadDe0_f(int Numeros[100]);
int main(){


    int Numeros[100];
    CargarDatos(&Numeros[100]);
    MostrarDatos(&Numeros[100]);


    cout<<"Se Han Encontrado: "<<MostrarCantidadDe0_f(&Numeros[100]);
    return 0;
}

void CargarDatos(int Numeros[100]){

 srand(time(NULL));
    for (int i = 0; i < 100; i++)
    {
        
        int num = rand(); num=rand()%51;
        Numeros[i] = num;
    }
}

void MostrarDatos(int Numeros[100]){
    int contador = 0;
    for (int i = 0; i < 100; i++)
    {
        contador = contador + Numeros[i];
    }
    
    cout<<"El Promedio Total Es De: "<<contador<<endl;
}


int MostrarCantidadDe0_f(int Numeros[100]){
 int numeros0Encontrados = 0;
 for (int i = 0; i < 100; i++)
 {
     if(Numeros[i] == 0)numeros0Encontrados++;
 }
 
 return numeros0Encontrados;
}