#include <iostream>
using namespace std;

/* Punto 1
    struct Maquinas{
        int Codigo;
        int Modelo;
        char Marca;
        int Control[3];
        struct Cliente{
         char Nombre;
         char Apellido;
         char Telefono;
        };
    };
    */
    


void Datos(int *numero);

int main(){

    int numero = 0;
    Datos(&numero); // la variable (0) se pasa al procedimiento Datos.
    cout<<numero; // Muestra El Dato
    return 0;
}

void Datos(int *numero){ // Esta variable suma 5 a la variable que se paso por referencia del main (0) en este caso,
    *numero = *numero + 5; // Suma 5 y automaticamente lo 'retorna' al main, al retornarlo la variable 'numero' del main cambia al '5'
}
